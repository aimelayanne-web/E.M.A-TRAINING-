E.M.A TRAINING — Projet Android hors connexion
================================================

Fonctions incluses
- Tableau de bord
- Création et suppression de plusieurs groupes (U12, U15, U18, OPEN, etc.)
- Création et suppression de séances
- Date/heure, groupe concerné, objectif, ateliers/exercices et durée
- Enregistrement local sur le téléphone, sans Internet
- Interface aux couleurs bleu marine et or, inspirée de l'identité E.M.A BASKET

COMPILATION DE L'APK
1. Sur un ordinateur, installer Android Studio depuis le site officiel Android Developers.
2. Décompresser EMA_TRAINING_Android.zip.
3. Dans Android Studio, choisir Open puis sélectionner le dossier EMA_TRAINING_Android.
4. Accepter la synchronisation Gradle et installer le SDK demandé si Android Studio le propose.
5. Dans le menu Build, choisir Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio indiquera le chemin du fichier APK généré. Transférer l'APK sur le téléphone Android et l'installer.
   Sur le téléphone, il peut être nécessaire d'autoriser l'installation depuis la source utilisée.

NOTES
- Le projet est un point de départ simple, sans compte utilisateur ni serveur.
- Les données restent sur le téléphone où elles ont été saisies. Désinstaller l'application peut les effacer.
- Le logo officiel E.M.A n'était pas inclus dans cette demande; le bandeau utilise donc le nom E.M.A BASKET en texte.
- La compilation nécessite un ordinateur avec Android Studio et les composants Android nécessaires. L'utilisation d'Android Studio est gratuite.
- Pour une utilisation réelle avec des mineurs, protéger le téléphone et éviter d'enregistrer des informations personnelles sensibles inutiles.
