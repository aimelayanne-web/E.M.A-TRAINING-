package mg.ema.training;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int NAVY = Color.rgb(9,42,69);
    private final int GOLD = Color.rgb(245,166,35);
    private final int PALE = Color.rgb(244,247,250);
    private LinearLayout root, content;
    private String page = "home";
    private JSONArray groups, sessions;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("ema_training", MODE_PRIVATE);
        groups = loadArray("groups");
        sessions = loadArray("sessions");
        showPage("home");
    }

    private JSONArray loadArray(String key) {
        try { return new JSONArray(prefs.getString(key, "[]")); }
        catch(Exception e) { return new JSONArray(); }
    }
    private void save() {
        prefs.edit().putString("groups", groups.toString()).putString("sessions", sessions.toString()).apply();
    }
    private void showPage(String target) {
        page = target;
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(PALE);
        setContentView(root);
        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(20,20,20,18); header.setBackgroundColor(NAVY);
        TextView brand = new TextView(this); brand.setText("E.M.A BASKET"); brand.setTextColor(GOLD); brand.setTextSize(14); brand.setTypeface(null,Typeface.BOLD);
        TextView title = new TextView(this); title.setText("TRAINING"); title.setTextColor(Color.WHITE); title.setTextSize(27); title.setTypeface(null,Typeface.BOLD);
        TextView subtitle = new TextView(this); subtitle.setText("Coach • Organisation hors connexion"); subtitle.setTextColor(Color.LTGRAY); subtitle.setTextSize(13);
        header.addView(brand); header.addView(title); header.addView(subtitle); root.addView(header);
        HorizontalScrollView navScroll = new HorizontalScrollView(this); navScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout nav = new LinearLayout(this); nav.setPadding(8,8,8,8); nav.setBackgroundColor(Color.WHITE);
        nav.addView(navButton("Accueil","home")); nav.addView(navButton("Groupes","groups")); nav.addView(navButton("Séances","sessions"));
        navScroll.addView(nav); root.addView(navScroll);
        ScrollView scroll = new ScrollView(this); content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(16,14,16,24);
        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if ("home".equals(page)) home(); else if ("groups".equals(page)) groupPage(); else sessionPage();
    }
    private Button navButton(String label, final String target) {
        Button b = new Button(this); b.setText(label); b.setTextColor(NAVY); b.setAllCaps(false);
        b.setOnClickListener(v -> showPage(target)); return b;
    }
    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextColor(NAVY); t.setTextSize(size);
        if (bold) t.setTypeface(null,Typeface.BOLD); t.setPadding(0,6,0,6); return t;
    }
    private void card(String title, String desc) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(16,12,16,12);
        box.setBackgroundColor(Color.WHITE);
        TextView h = text(title,18,true); TextView d = text(desc,14,false);
        box.addView(h); box.addView(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,12); content.addView(box,lp);
    }
    private Button action(String label, Runnable run) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(NAVY));
        b.setOnClickListener(v -> run.run()); return b;
    }
    private void home() {
        content.addView(text("Tableau de bord",23,true));
        card("Groupes enregistrés", String.valueOf(groups.length())+" groupe(s)");
        card("Séances enregistrées", String.valueOf(sessions.length())+" séance(s)");
        content.addView(action("+ Créer un groupe", () -> groupDialog()));
        content.addView(action("+ Planifier une séance", () -> sessionDialog()));
        content.addView(text("Conseil : les données sont conservées sur ce téléphone. Aucune connexion Internet n’est nécessaire.",14,false));
    }
    private void groupPage() {
        content.addView(text("Gestion des groupes",23,true));
        content.addView(action("+ Ajouter un groupe", () -> groupDialog()));
        if (groups.length()==0) content.addView(text("Aucun groupe pour le moment. Ajoutez par exemple U12, U15, U18 ou OPEN.",15,false));
        for (int i=0;i<groups.length();i++) {
            final int index=i; JSONObject g=groups.optJSONObject(i); if(g==null) continue;
            String name=g.optString("name","Groupe"), age=g.optString("age",""), note=g.optString("note","");
            card(name, (age.isEmpty()?"":age+" • ")+note);
            content.addView(action("Supprimer "+name, () -> confirmDeleteGroup(index,name)));
        }
    }
    private void sessionPage() {
        content.addView(text("Programme des séances",23,true));
        content.addView(action("+ Nouvelle séance", () -> sessionDialog()));
        if (sessions.length()==0) content.addView(text("Aucune séance planifiée. Créez une séance avec sa date, son groupe, son objectif et son contenu.",15,false));
        for (int i=0;i<sessions.length();i++) {
            JSONObject s=sessions.optJSONObject(i); if(s==null) continue;
            String info=s.optString("date","Date à préciser")+" • "+s.optString("group","Tous groupes");
            String details="Objectif : "+s.optString("goal","—")+"\nAteliers : "+s.optString("drills","—")+"\nDurée : "+s.optString("duration","—");
            card(s.optString("title","Séance"),info+"\n"+details);
            final int index=i; content.addView(action("Supprimer cette séance", () -> {
                new AlertDialog.Builder(this).setTitle("Supprimer la séance ?").setMessage(s.optString("title","Séance"))
                    .setNegativeButton("Annuler",null).setPositiveButton("Supprimer",(d,w)->{sessions.remove(index);save();showPage("sessions");}).show();
            }));
        }
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setSingleLine(false); e.setTextSize(16); return e;
    }
    private void groupDialog() {
        LinearLayout form = new LinearLayout(this); form.setPadding(20,0,20,0); form.setOrientation(LinearLayout.VERTICAL);
        EditText name=field("Nom du groupe (ex. U12 Filles)"), age=field("Catégorie / âge"), note=field("Remarques (facultatif)");
        form.addView(name); form.addView(age); form.addView(note);
        new AlertDialog.Builder(this).setTitle("Créer un groupe").setView(form)
            .setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{
                if(name.getText().toString().trim().isEmpty()){toast("Entrez le nom du groupe.");return;}
                JSONObject g=new JSONObject(); try {g.put("name",name.getText().toString().trim());g.put("age",age.getText().toString().trim());g.put("note",note.getText().toString().trim());groups.put(g);}catch(Exception ignored){}
                save();showPage("groups");
            }).show();
    }
    private void sessionDialog() {
        LinearLayout form = new LinearLayout(this); form.setPadding(20,0,20,0); form.setOrientation(LinearLayout.VERTICAL);
        EditText title=field("Titre (ex. Dribble et coordination)"), date=field("Date et heure (ex. 15/10/2026 - 15:00)"),
            goal=field("Objectif de la séance"), drills=field("Ateliers / exercices"), duration=field("Durée (ex. 90 minutes)");
        Spinner spinner=new Spinner(this); java.util.ArrayList<String> options=new java.util.ArrayList<>(); options.add("Tous groupes");
        for(int i=0;i<groups.length();i++){JSONObject g=groups.optJSONObject(i);if(g!=null)options.add(g.optString("name","Groupe"));}
        spinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,options));
        form.addView(title);form.addView(date);form.addView(new TextView(this){{setText("Groupe concerné");setTextColor(NAVY);setPadding(0,8,0,0);}});form.addView(spinner);
        form.addView(goal);form.addView(drills);form.addView(duration);
        new AlertDialog.Builder(this).setTitle("Planifier une séance").setView(form)
            .setNegativeButton("Annuler",null).setPositiveButton("Enregistrer",(d,w)->{
                if(title.getText().toString().trim().isEmpty()){toast("Entrez le titre de la séance.");return;}
                JSONObject s=new JSONObject();try{s.put("title",title.getText().toString().trim());s.put("date",date.getText().toString().trim());s.put("group",spinner.getSelectedItem().toString());s.put("goal",goal.getText().toString().trim());s.put("drills",drills.getText().toString().trim());s.put("duration",duration.getText().toString().trim());sessions.put(s);}catch(Exception ignored){}
                save();showPage("sessions");
            }).show();
    }
    private void confirmDeleteGroup(int index,String name) {
        new AlertDialog.Builder(this).setTitle("Supprimer le groupe ?").setMessage("Les séances déjà créées ne seront pas supprimées.")
            .setNegativeButton("Annuler",null).setPositiveButton("Supprimer",(d,w)->{groups.remove(index);save();showPage("groups");}).show();
    }
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_SHORT).show();}
}
